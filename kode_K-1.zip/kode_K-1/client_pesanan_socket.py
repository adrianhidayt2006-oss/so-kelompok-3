import json
import socket

def kirim(f, pesan):
    f.write(json.dumps(pesan) + "\n")
    f.flush()
    return json.loads(f.readline())

kode_produk = "P999"
jumlah_pesan = 5

with socket.create_connection(("localhost", 9000)) as s:
    f = s.makefile("rw", encoding="utf-8")
    print(f"[Client Socket] Memeriksa stok untuk {kode_produk}...")
    stok_awal = kirim(f, {"aksi": "cek", "kode": kode_produk})["stok"]
    print(f"[Client Socket] Stok tersedia: {stok_awal}")
    if stok_awal >= jumlah_pesan:
        r = kirim(f, {"aksi": "potong", "kode": kode_produk, "jumlah": jumlah_pesan})
        if r["ok"]:
            print(f"[Client Socket] Berhasil memesan {jumlah_pesan} unit {kode_produk}!")
            print(f"[Client Socket] Sisa stok di server sekarang: {r['stok']}")
    else:
        print(f"[Client Socket] Gagal: Stok {kode_produk} tidak mencukupi.")
