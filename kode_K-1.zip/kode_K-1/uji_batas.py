import json, socket, threading
def kirim(f, m):
    f.write(json.dumps(m) + "\n"); f.flush(); return json.loads(f.readline())
hasil = []
def pesan():
    c = socket.create_connection(("localhost", 9000)); f = c.makefile("rw")
    hasil.append(kirim(f, {"aksi": "potong", "kode": "P001", "jumlah": 3})["ok"]); c.close()
t = [threading.Thread(target=pesan) for _ in range(20)]
[x.start() for x in t]; [x.join() for x in t]
c = socket.create_connection(("localhost", 9000)); f = c.makefile("rw")
print("20 client x 3 unit, stok P001 = 50 -> berhasil:", sum(hasil), "gagal:", hasil.count(False),
      "stok akhir:", kirim(f, {"aksi": "cek", "kode": "P001"})["stok"])
