import json
import socketserver
import threading

stok_db = {"P001": 50, "P002": 30, "P999": 20}
kunci = threading.Lock()

def proses(perintah):
    aksi = perintah.get("aksi")
    kode = perintah.get("kode")
    if aksi == "cek":
        return {"ok": True, "stok": stok_db.get(kode, 0)}
    if aksi == "potong":
        jumlah = perintah.get("jumlah", 0)
        with kunci:  # cek dan potong dibuat atomik
            ada = stok_db.get(kode, 0)
            if ada >= jumlah:
                stok_db[kode] = ada - jumlah
                return {"ok": True, "stok": stok_db[kode]}
            return {"ok": False, "stok": ada}
    return {"ok": False, "error": "aksi tidak dikenal"}

class Penangan(socketserver.StreamRequestHandler):
    def handle(self):
        for baris in self.rfile:  # satu pesan JSON per baris
            try:
                jawab = proses(json.loads(baris))
            except (ValueError, AttributeError):
                jawab = {"ok": False, "error": "format pesan salah"}
            self.wfile.write((json.dumps(jawab) + "\n").encode())

class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

if __name__ == "__main__":
    with Server(("localhost", 9000), Penangan) as s:
        print("[Socket Server] Layanan Stok siap berjalan di port 9000...")
        try:
            s.serve_forever()
        except KeyboardInterrupt:
            print("\n[Socket Server] Layanan dihentikan.")
