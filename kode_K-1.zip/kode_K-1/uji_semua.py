import json, socket, threading, time, xmlrpc.client
print("=== A. XML-RPC (urutan uji pada server baru) ===")
p = xmlrpc.client.ServerProxy("http://localhost:8000/")
print("A1 cek_stok('P999')          ->", p.cek_stok("P999"))
print("A2 potong_stok('P999', 5)    ->", p.potong_stok("P999", 5))
print("A3 potong_stok('P001', 60)   ->", p.potong_stok("P001", 60))
print("A4 cek_stok('P404')          ->", p.cek_stok("P404"))
print("A5 potong_stok('P404', 1)    ->", p.potong_stok("P404", 1))
print("A6 potong_stok('P002', 30)   ->", p.potong_stok("P002", 30))
print("A7 potong_stok('P002', 1)    ->", p.potong_stok("P002", 1))
print("\n=== B. Socket (server baru) ===")
def kirim(f, m):
    f.write(json.dumps(m) + "\n"); f.flush(); return json.loads(f.readline())
s = socket.create_connection(("localhost", 9000)); f = s.makefile("rw")
print("B1 cek P999        ->", kirim(f, {"aksi": "cek", "kode": "P999"}))
print("B2 potong P999 x5  ->", kirim(f, {"aksi": "potong", "kode": "P999", "jumlah": 5}))
print("B3 potong P001 x60 ->", kirim(f, {"aksi": "potong", "kode": "P001", "jumlah": 60}))
print("B4 aksi salah      ->", kirim(f, {"aksi": "hapus", "kode": "P001"}))
f.write("bukan json\n"); f.flush(); print("B5 pesan rusak     ->", json.loads(f.readline()))
s.close()
print("\n=== C. 10 client socket paralel, masing-masing pesan 3 unit P001 (stok 50) ===")
hasil = []
def pesan():
    c = socket.create_connection(("localhost", 9000)); ff = c.makefile("rw")
    hasil.append(kirim(ff, {"aksi": "potong", "kode": "P001", "jumlah": 3})["ok"]); c.close()
t = [threading.Thread(target=pesan) for _ in range(10)]
[x.start() for x in t]; [x.join() for x in t]
c = socket.create_connection(("localhost", 9000)); ff = c.makefile("rw")
print("berhasil:", sum(hasil), "gagal:", hasil.count(False), "stok akhir:", kirim(ff, {"aksi": "cek", "kode": "P001"})["stok"])
print("\n=== D. Latensi rata-rata per panggilan cek stok (1000 panggilan) ===")
N = 1000
t0 = time.perf_counter()
for _ in range(N): p.cek_stok("P999")
x = (time.perf_counter() - t0) / N * 1000
t0 = time.perf_counter()
for _ in range(N): kirim(ff, {"aksi": "cek", "kode": "P999"})
y = (time.perf_counter() - t0) / N * 1000
print(f"XML-RPC: {x:.3f} ms | Socket: {y:.3f} ms")
print("\n=== E. Ukuran pesan ===")
req = xmlrpc.client.dumps(("P999",), "cek_stok")
print("XML-RPC request :", len(req.encode()), "byte (belum termasuk header HTTP)")
print(req)
m = json.dumps({"aksi": "cek", "kode": "P999"}) + "\n"
print("Socket request  :", len(m.encode()), "byte ->", m.strip())
